import { useState, useEffect } from 'react';
import { ChatBox } from '@/components/ChatBox';
import { UsernameDialog } from '@/components/UsernameDialog';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { Message, User } from '@/types/chat';
import { MessageSquare } from 'lucide-react';

const Index = () => {
  const [user, setUser] = useLocalStorage<User | null>('chatbox-user', null);
  const [messages, setMessages] = useLocalStorage<Message[]>('chatbox-messages', []);
  const [showDialog, setShowDialog] = useState(false);

  useEffect(() => {
    if (!user) {
      setShowDialog(true);
    }
  }, [user]);

  const handleSetUsername = (username: string) => {
    const newUser: User = {
      username,
      color: `hsl(${Math.random() * 360}, 70%, 50%)`,
    };
    setUser(newUser);
    setShowDialog(false);
  };

  const handleSendMessage = (content: string, replyTo?: Message) => {
    if (!user) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      username: user.username,
      content,
      timestamp: Date.now(),
      replyTo: replyTo
        ? {
            id: replyTo.id,
            username: replyTo.username,
            content: replyTo.content,
          }
        : undefined,
    };

    setMessages([...messages, newMessage]);
  };

  return (
    <div className="min-h-screen bg-gradient-subtle flex flex-col items-center justify-center p-4">
      <div className="mb-8 text-center animate-fade-in">
        <div className="flex items-center justify-center gap-3 mb-2">
          <MessageSquare className="w-10 h-10 text-primary animate-glow" />
          <h1 className="text-4xl font-bold bg-gradient-primary bg-clip-text text-transparent">
            ChatBox
          </h1>
        </div>
        <p className="text-muted-foreground">
          Connect and discuss with people around the world
        </p>
      </div>

      {user && (
        <ChatBox
          messages={messages}
          currentUsername={user.username}
          onSendMessage={handleSendMessage}
        />
      )}

      <UsernameDialog open={showDialog} onSubmit={handleSetUsername} />
    </div>
  );
};

export default Index;
